package com.example.wirelessscanner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.maps.GoogleMap;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PassiveScanner extends AppCompatActivity {

    private double myLat = 0.0;
    private double myLong = 0.0;
    private int Location_Request = 1;
    WifiManager wifiManager;
    ArrayList<WirelessNode> NodeList = new ArrayList<>();
    private List<ScanResult> results;
    private WirelessNode temp;
    private int Incoming_Packets = 0;
    private int Nodes = 0;
    private int PAN_Nodes = 0;
    private int CDMA_Nodes = 0;
    private int GSM_Nodes = 0;
    private int Bluetooth_Nodes = 0;
    private int ANT_Nodes = 0;


    static final int PICK_CONTACT_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passive_scanner);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent getLocation = new Intent(this, MyLocation.class);
        startActivityForResult(getLocation, Location_Request);
        updateScreen();
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(this, "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
            wifiManager.setWifiEnabled(true);
        }

        Button scanButton = (Button)findViewById(R.id.PassiveScannerGoButton);
        final AdapterView.OnClickListener ocl = new AdapterView.OnClickListener() {
            public void onClick(View v) {
                //System.out.println("Success");
                scanWifi();
                //Start Scanning local WIFI

            }

        };
        scanButton.setOnClickListener(ocl); // Sets the listener for the user clicking on the button
        scanButton.setEnabled(true);


        Button stopScanButton = (Button)findViewById(R.id.PassiveStop);
        final AdapterView.OnClickListener oc2 = new AdapterView.OnClickListener() {
            public void onClick(View v) {
                //System.out.println("Success");
                scanWifiStop();
                //Stop Scanning and store results

            }

        };
        stopScanButton.setOnClickListener(oc2); // Sets the listener for the user clicking on the button
        stopScanButton.setEnabled(true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Intent myIntent;
        myIntent = new Intent(this, MyLocation.class);
        // Check that it is the SecondActivity with an OK result
        if (requestCode == Location_Request) {
            if (resultCode == RESULT_OK) {

                // Get String data from Intent
                myLat = data.getDoubleExtra("myLat", 0.0);
                myLong = data.getDoubleExtra("myLong", 0.0);


            }
        }
    }


    private void scanWifi() {
        NodeList.clear();
        registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager.startScan();
        Toast.makeText(this, "Scanning WiFi ...", Toast.LENGTH_LONG).show();
    }


    BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        public void onReceive(Context context, Intent intent) {
            results = wifiManager.getScanResults();
            unregisterReceiver(this);

            for (ScanResult scanResult : results) {
                //NodeList.add(scanResult.SSID + " - " + scanResult.capabilities);=======

                temp.setDate();
                temp.setCurrentTime();
                temp.setDestinationname(scanResult.SSID);
                temp.setDeviceName(scanResult.BSSID);
                temp.setLattitude(myLat);
                temp.setLongitute(myLong);
                temp.setDeviceCommunicationProtocol(scanResult.capabilities);
                NodeList.add(temp);
                Incoming_Packets++;
                Nodes++;
                updateScreen();
            }
        }

        ;
    };

    private void scanWifiStop() {
        //NodeList.clear();
        Toast.makeText(this, "Stopping ..." + Nodes, Toast.LENGTH_LONG).show();
        writeDataToFile();
        finish();
    }

    private void writeDataToFile()
    {


    }

    private void writeToFile(String data,Context context) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("Nodes.txt", Context.MODE_PRIVATE));
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }

    private void updateScreen()
    {
        TextView incomingPackets = (TextView)findViewById(R.id.PassiveScannerPacketsCapturedNumber);
        incomingPackets.setText( String.valueOf(Incoming_Packets));
        TextView analizedPackets = (TextView)findViewById(R.id.PassiveScannerPacketsAnalyzedNumber);
        analizedPackets.setText(String.valueOf(Incoming_Packets));  //Revise with PCAP
        TextView numberOfNodes = (TextView)findViewById(R.id.PassiveScannerNodeCountNumber);
        numberOfNodes.setText(String.valueOf(Incoming_Packets));  //Revise with updated PCAP files
        TextView incomingPAN = (TextView)findViewById(R.id.PassiveScannerPANNumber);
        incomingPAN.setText(String.valueOf(PAN_Nodes));
        TextView incomingCDMA = (TextView)findViewById(R.id.PassiveScannerCDMACommunicationNumber);
        incomingCDMA.setText(String.valueOf(CDMA_Nodes));
        TextView incomingGSM = (TextView)findViewById(R.id.PassiveScannerGSMDetectedNumber);
        incomingGSM.setText(String.valueOf(GSM_Nodes));
        TextView incomingBluetooth = (TextView)findViewById(R.id.PassiveScannerBluetoothNumber);
        incomingBluetooth.setText(String.valueOf(Bluetooth_Nodes));
        TextView incomingANT = (TextView)findViewById(R.id.PassiveScannerANTNumber);
        incomingANT.setText(String.valueOf(ANT_Nodes));

    }

}
