package com.example.wirelessscanner;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.maps.GoogleMap;

public class PassiveScanner extends AppCompatActivity {

    private double myLat = 0.0;
    private double myLong = 0.0;
    private int Location_Request = 1;


    static final int PICK_CONTACT_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passive_scanner);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent getLocation = new Intent(this, MyLocation.class);
        startActivityForResult(getLocation, Location_Request);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Intent myIntent;
        myIntent = new Intent(this, MyLocation.class);
        // Check that it is the SecondActivity with an OK result
        if (requestCode == Location_Request) {
            if (resultCode == RESULT_OK) {

                // Get String data from Intent
                myLat = data.getDoubleExtra("myLat", 0.0);
                myLong = data.getDoubleExtra("myLong", 0.0);


            }
        }
    }



}
