package com.example.wirelessscanner;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class WirelessNode {
    //Host Node information
    private char[] MACAddress = new char[6]; // MAC address for the device FF:FF:FF:FF:FF:FF
    private int[] IPV4AddressHost = new int[4]; // Node IPV4 address XXX.XXX.XXX.XXX
    private char[] IPV6AddressHost = new char[32]; //128 bits represented in hex
    private String name = "";
    private String CommunicationProtocol = "";

    //Destination
    private int[] IPV4AddressDestination = new int[4]; // Node IPV4 address XXX.XXX.XXX.XXX
    private char[] IPV6AddressDestination = new char[32]; //128 bits represented in hex
    private String Destinationname = "";

    //Location Data
    private double lattitude = 0.0;
    private double longitute = 0.0;
    private LocalDateTime currentTime;
    private LocalDate date1;

    /***********************************************************************************************
     * Getters
     **********************************************************************************************/

    public char[] getMACAddress()
    {

        return MACAddress;
    }

    public int[] getIPV4AddressHost()
    {
        return IPV4AddressHost;
    }

    public char[] getIPV6AddressHost()
    {
        return IPV6AddressHost;
    }

    public String getDeviceName()
    {
        return name;
    }

    public String getDeviceCommunicationProtocol()
    {
        return CommunicationProtocol;
    }

    public int[] getIPV4AddressDestination()
    {
        return IPV4AddressDestination;
    }

    public char[] getIPV6AddressDestination() {
        return IPV6AddressDestination;
    }

    public String getDestinationname()
    {
        return Destinationname;     //In some cases the destination is going to be popular, and we can associate a name with it
    }

    public double getLattitude() {
        return lattitude;
    }

    public double getLongitute() {
        return longitute;
    }

    public LocalDateTime getCurrentTime()
    {
        return currentTime;
    }

    public LocalDate getDate()
    {
        return date1;
    }

    /**********************************************************************************************
     * Setters
     **********************************************************************************************/
    public void  setMACAddress(char[] newMAC)
    {
        MACAddress = newMAC;

    }

    public  void setIPV4AddressHost(int[] newIPVAddressHost)
    {
        IPV4AddressHost = newIPVAddressHost;
    }

    public void setIPV6AddressHost(char[] newIPV6AddressHost)
    {
        IPV6AddressHost = newIPV6AddressHost;
    }

    public void setDeviceName(String newDeviceName)
    {
        name = newDeviceName;
    }

    public void setDeviceCommunicationProtocol( String newCommunicationProtocol)
    {
        CommunicationProtocol = newCommunicationProtocol;
    }

    public void setIPV4AddressDestination(int[] newIPV4AddressDestination)
    {
        IPV4AddressDestination = newIPV4AddressDestination;
    }

    public void setIPV6AddressDestination( char[] newIPV6AddressDestination) {
        IPV6AddressDestination = newIPV6AddressDestination;
    }

    public void setDestinationname( String newDestinationname)
    {
        Destinationname = newDestinationname;     //In some cases the destination is going to be popular, and we can associate a name with it
    }

    public void setLattitude( double newLattitude) {
        lattitude = newLattitude;
    }

    public void setLongitute( double newLongitute) {
        longitute = newLongitute;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setCurrentTime( )
    {
        currentTime = LocalDateTime.now();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void setDate( )
    {
        date1 = currentTime.toLocalDate();;
    }

}
